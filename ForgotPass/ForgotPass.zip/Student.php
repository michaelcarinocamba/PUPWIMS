<?php
//Import PHPMailer classes into the global namespace
//These must be at the top of your script, not inside a function
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
require '../db_conn.php';

if(isset($_POST["email"]))
{
    $emailTo = $_POST['email'];
    $code = uniqid(true);
    $query = mysqli_query($conn, "INSERT INTO student_reset(code, email) VALUES('$code' , '$emailTo')");
    if(!$query)
    {
        exit("Error");
    }

    $mail = new PHPMailer(true);

try {
    //Server settings
              //Enable verbose debug output
    $mail->isSMTP();                                            //Send using SMTP
    $mail->Host       = 'smtp.office365.com';                     //Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
    $mail->Username   = 'pupwims@outlook.com';                     //SMTP username
    $mail->Password   = 'pupsjwims123!';                               //SMTP password
    $mail->SMTPSecure = 'TLS';            //Enable implicit TLS encryption
    $mail->Port       = 587;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

    //Recipients
    $mail->setFrom('pupwims@outlook.com', 'Admin');
    $mail->addAddress($emailTo);     //Add a recipient           


    //Content
    $url = "http://" . $_SERVER["HTTP_HOST"] . dirname($_SERVER["PHP_SELF"]) . "/Student.php?code=$code";
    $mail->isHTML(true);                                  //Set email format to HTML
    $mail->Subject = 'Request New Password';
    $mail->Body    = "<h1>You requested a password reset</h1>
                        Click <a href='$url'>this link</a> for you to proceed!";
    $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

    $mail->send();
    echo "<script> location.href='../ForgotPass/SuccessRequest.php'; </script>";
        exit;
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}
exit();
}

if(isset($_REQUEST["code"]))
{
    $uniqcode = $_GET["code"];

    $getEmailQuery = mysqli_query($conn, "SELECT email FROM student_reset WHERE code = '$uniqcode'");

    if(mysqli_num_rows($getEmailQuery) == 0)
    {
        exit("Can't find page");
    }

    if(isset($_POST["password"]))
    {
        $pw = $_POST["password"];
        

        $row = mysqli_fetch_array($getEmailQuery);
        $email = $row["email"];

        $query = mysqli_query($conn, "UPDATE student_info SET password = '$pw' WHERE email = '$email'");
        if($query)
        {
            $query = mysqli_query($conn, "DELETE FROM student_reset WHERE code = '$uniqcode'");
        }
        else{
            exit("Something went wrong");
        }

        
        echo "<script> location.href='Student.php?successpassword'; </script>";
            exit;

    }

    ?>

    <!DOCTYPE html>
    <html lang="en" style = "height: auto;">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>PUPSJ Intern Reset Password</title>
        <link rel = "stylesheet" href = "../css/style.css">
    </head>
    <body>
        <section>
            <div class = "Background">
                <img src = "../images/bgsj.jpg">
            </div>
            <div class = "Content">
                <div class = "form" >
                    <center>
                <img alt="PUP" class="img-circle" src="../images/pupsjlogo.png"><br>
                    
                <h1>New Password</h1><br>
                
                <h3>Please enter your new password</h3>
                </center>
                
                <form method="post">
                
                
                <div class = "input">
                    <span>Password</span><input type="password" name="password" placeholder="New Password"><br><br>
                    <center>
                    <button type="submit" name="submit" class="button" style="width:auto;">Update Password</button> <br><br>
                    
                    <p>Go back to <a href="../Student/Student_Login.php">Sign in</a><br><br></p>
                    <h6> By using this service, you understood and agree to the PUP Online Services <a href="https://www.pup.edu.ph/terms/" target="_blank">Terms of Use</a> and <a href="https://www.pup.edu.ph/privacy/" target="_blank"> Privacy Statement</a></h6>
                    </center>
                </div>
                </form>
            </div>
            </div>
            
        </section>
    </body>
    </html>
 <?php
}

if(isset($_REQUEST['successpassword']))
{
    ?>
        
    <!DOCTYPE html>
    <html lang="en" style = "height: auto;">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Update Password</title>
        <link rel = "stylesheet" href = "../css/style.css">
    </head>
    <body>
        <section>
            <div class = "Background">
                <img src = "../images/bgsj.jpg">
            </div>
            <div class = "Content">
                <div class = "form" >
                    <center>
                <img alt="PUP" class="img-circle" src="../images/pupsjlogo.png"><br>
                    
                <h1>Password Updated</h1><br>
                
                <h3>Please proceed to the login</h3><br><br>

                
                <form action="../Student/Student_Login.php" method="post">
                
                <button type="submit" name="submit" class="button" style="color:white; background-color:maroon;">Login</button> <br><br><br>
                
                        
                <h6> By using this service, you understood and agree to the PUP Online Services <a href="https://www.pup.edu.ph/terms/" target="_blank">Terms of Use</a> and <a href="https://www.pup.edu.ph/privacy/" target="_blank"> Privacy Statement</a></h6>
                    </center>
                </div>
                </form>
            </div>
            </div>
            
        </section>
    </body>
    </html>
    <?php
}

?>

<!DOCTYPE html>
<html lang="en" style = "height: auto;">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password</title>
    <link rel = "stylesheet" href = "../css/style.css">
</head>
<body>
    <section>
        <div class = "Background">
            <img src = "../images/bgsj.jpg">
        </div>
        <div class = "Content">
            <div class = "form" >
                <center>
            <img alt="PUP" class="img-circle" src="../images/pupsjlogo.png"><br>
                
            <h1>Forgot Password</h1><br>
            
            <h3>Please enter your email account</h3>
            </center>
            
            <form method="post">
            
            
            <div class = "input">
                <span>Email Address</span><input type="text" name="email" autocomplete="off" ><br><br>
                <center>
                <button type="submit" name="submit" class="button" style="width:auto;">Request new password</button> <br>
                
                <p>Go back to <a href="../Student/Student_Login.php">Sign in</a><br><br></p>
                <h6> By using this service, you understood and agree to the PUP Online Services <a href="https://www.pup.edu.ph/terms/" target="_blank">Terms of Use</a> and <a href="https://www.pup.edu.ph/privacy/" target="_blank"> Privacy Statement</a></h6>
                </center>
            </div>
            </form>
        </div>
        </div>
        
    </section>
</body>
</html>